<?php
//on helper load run this function


?>