<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Modelbook extends CI_Model {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->table = 'book';
        $this->load->helper('global');
    }

    public function insert($data){
        $data['id'] = random_id(64);
        if ($this->db->insert($this->table, $data)) {
            return $data['id'];
        } else {
            return false;
        }
    }

    public function update($id, $data){
        $this->db->where('id', $id);
        if ($this->db->update($this->table, $data)) {
            return true;
        } else {
            return false;
        }
    }

    public function delete($id){
        $this->db->where('id', $id);
        if ($this->db->delete($this->table)) {
            return true;
        } else {
            return false;
        }
    }

    //ALWAYS CHECK OWNERSHIP FOR UPDATE AND DELETE
    public function check_ownership($id, $school_id){
        $this->db->where('id', $id);
        $this->db->where('school_id', $school_id);
        $query = $this->db->get($this->table);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    public function get($id, $school_id){
        $this->db->where('id', $id);
        $this->db->where('school_id', $school_id);
        $query = $this->db->get($this->table);
        return $query->row();
    }

    public function get_all($school_id){
        $this->db->where('school_id', $school_id);
        $query = $this->db->get($this->table);
        return $query->result();
    }

    public function get_all_min($school_id){
        $this->db->select('id, isbn, title, category, created');
        $this->db->where('school_id', $school_id);
        $query = $this->db->get($this->table);
        return $query->result();
    }
}

?>