<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Modelbook_categories extends CI_Model {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->table = 'book_categories';
        $this->load->helper('global');
    }
    
    public function get($id){
        $this->db->where('id', $id);
        $query = $this->db->get($this->table);
        return $query->row();
    }

    public function get_in($ids){
        $this->db->where_in('id', $ids);
        $query = $this->db->get($this->table);
        return $query->result();
    }

    public function get_all(){
        $query = $this->db->get($this->table);
        return $query->result();
    }
}

?>