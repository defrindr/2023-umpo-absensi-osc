<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Modelborrow extends CI_Model {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->table = 'borrow';
        $this->view = 'summary';
        $this->load->helper('global');
    }

    public function insert($data){
        $data['id'] = random_id(128);
        if ($this->db->insert($this->table, $data)) {
            return $data['id'];
        } else {
            return false;
        }
    }

    public function update($id, $data){
        $this->db->where('id', $id);
        if ($this->db->update($this->table, $data)) {
            return true;
        } else {
            return false;
        }
    }

    public function finish($id){
        $this->db->where('id', $id);
        $this->db->set('return_date', 'NOW()', FALSE);
        if ($this->db->update($this->table)) {
            return true;
        } else {
            return false;
        }
    }

    public function delete($id){
        $this->db->where('id', $id);
        if ($this->db->delete($this->table)) {
            return true;
        } else {
            return false;
        }
    }

    //ALWAYS CHECK OWNERSHIP FOR UPDATE AND DELETE
    public function check_ownership($id, $school_id){
        $this->db->where('id', $id);
        $this->db->where('school_id', $school_id);
        $query = $this->db->get($this->table);
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    public function get($id, $school_id){
        return false;
        $this->db->where('id', $id);
        $this->db->where('school_id', $school_id);
        $query = $this->db->get($this->view);
        return $query->row();
    }

    public function get_all($school_id){
        $this->db->where('school_id', $school_id);
        $query = $this->db->get($this->view);
        return $query->result();
    }

    public function get_all_min($school_id){
        $this->db->select('id, nim, student, title, return_date, created');
        $this->db->where('school_id', $school_id);
        $query = $this->db->get($this->view);
        return $query->result();
    }

    public function get_min_by_student($student_id, $school_id){
        $this->db->select('id, nim, student, title, return_date, created');
        $this->db->where('student_id', $student_id);
        $this->db->where('school_id', $school_id);
        #where return_date is null
        $this->db->where('return_date', null);

        $query = $this->db->get($this->view);
        return $query->result();
    }

    public function get_min_by_month($month, $school_id){
        $this->db->select('id, nim, student, title, return_date, created');
        $this->db->where('school_id', $school_id);
        $this->db->where('MONTH(created)', $month);
        $query = $this->db->get($this->view);
        return $query->result();
    }

    public function get_min_unreturned($school_id){
        $this->db->select('id, nim, student, title, return_date, created');
        $this->db->where('school_id', $school_id);
        #where return_date is null
        $this->db->where('return_date', null);
        $query = $this->db->get($this->view);
        return $query->result();
    }
}

?>