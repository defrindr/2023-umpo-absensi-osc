<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Borrow extends CI_Controller {
    //load sensors model
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Modelborrow');
        $this->load->model('Modelsession');

        $this->load->helper('global');
        header('Content-Type: application/json');

        //call helper cors check
        if(!cors_check()){
            $response = array(
                'status' => 403,
                'message' => 'Invalid/Expired key',
                'data' => null
            );
            reply($response);
        }

        if(ENVIRONMENT == 'testing' || ENVIRONMENT == 'production'){
            //set school_id variable
            $this->school_id = $this->Modelsession->get_school_id($this->input->get_request_header('Authorization', TRUE));

            //if null, reply with 403 status
            if($this->school_id == null){
                $response = array(
                    'status' => 403,
                    'message' => 'MISSING SCHOOL ID',
                    'data' => null
                );
                reply($response);
            }
        }
    }

    public function all(){
        $response = array(
            'status' => 200,
            'message' => 'Fetch all borrow',
            'data' => $this->Modelborrow->get_all($this->school_id)
        );

        reply($response);
    }

    public function min(){
        $response = array(
            'status' => 200,
            'message' => 'Fetch minimal info of all borrow',
            'data' => $this->Modelborrow->get_all_min($this->school_id)
        );

        reply($response);
    }

    public function min_month(){
        $month = $this->input->post('month');

        if(empty($month)){
            $response = array(
                'status' => 400,
                'message' => 'Invalid data',
                'data' => null
            );
            reply($response);
        }

        $response = array(
            'status' => 200,
            'message' => 'Fetch minimal info of all borrow',
            'data' => $this->Modelborrow->get_min_by_month($month, $this->school_id)
        );

        reply($response);
    }

    public function min_unreturned(){
        $response = array(
            'status' => 200,
            'message' => 'Fetch minimal info of all borrow',
            'data' => $this->Modelborrow->get_min_unreturned($this->school_id)
        );

        reply($response);
    }

    public function by_student(){
        $student_id = $this->input->post('student_id');

        if(empty($student_id)){
            $response = array(
                'status' => 400,
                'message' => 'Invalid data',
                'data' => null
            );
            reply($response);
        }

        $response = array(
            'status' => 200,
            'message' => 'Fetch borrow by student',
            'data' => $this->Modelborrow->get_min_by_student($student_id, $this->school_id)
        );

        reply($response);
    }

    public function create(){
        $data = array(
            'student_id' => $this->input->post('student_id'),
            'book_id' => $this->input->post('book_id'),
        );

        if(!array_empty_check($data)){
            $response = array(
                'status' => 400,
                'message' => 'Invalid data',
                'data' => $data
            );
            reply($response);
        }

        //set school_id
        $data['school_id'] = $this->school_id;

        $status = $this->Modelborrow->insert($data);

        if($status){
            $response = array(
                'status' => 201,
                'message' => 'Borrow created',
                'data' => $status
            );
        } else {
            $response = array(
                'status' => 500,
                'message' => 'Failed to create borrow',
                'data' => null
            );
        }

        reply($response);
    }

    public function finish(){
        $id = $this->input->post('id');

        //check if id is empty
        if(empty($id)){
            $response = array(
                'status' => 400,
                'message' => 'Invalid data',
                'data' => null
            );
            reply($response);
        }

        if(!$this->Modelborrow->check_ownership($id, $this->school_id)){
            $response = array(
                'status' => 403,
                'message' => 'Borrow is not owned by this school',
                'data' => null
            );
            reply($response);
        }

        if($this->Modelborrow->finish($id)){
            $response = array(
                'status' => 200,
                'message' => 'Borrow updated',
                'data' => null
            );
        } else {
            $response = array(
                'status' => 500,
                'message' => 'Failed to update borrow',
                'data' => null
            );
        }

        reply($response);
    }

    public function delete(){
        $id = $this->input->post('id');

        if(empty($id)) {
            $response = array(
                'status' => 400,
                'message' => 'Invalid data',
                'data' => null
            );
            reply($response);
        }

        if(!$this->Modelborrow->check_ownership($id, $this->school_id)){
            $response = array(
                'status' => 403,
                'message' => 'Borrow is not owned by this school or it does not exist',
                'data' => null
            );
            reply($response);
        }

        if($this->Modelborrow->delete($id)){
            $response = array(
                'status' => 200,
                'message' => 'Borrow deleted',
                'data' => null
            );
        } else {
            $response = array(
                'status' => 500,
                'message' => 'Failed to delete borrow',
                'data' => null
            );
        }

        reply($response);
    }
}
