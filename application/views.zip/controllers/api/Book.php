<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Book extends CI_Controller {
    //load sensors model
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Modelbook');
        $this->load->model('Modelsession');
        //$this->load->model('Modeltrans');

        $this->load->helper('global');
        header('Content-Type: application/json');

        //call helper cors check
        if(!cors_check()){
            $response = array(
                'status' => 403,
                'message' => 'Invalid/Expired key',
                'data' => null
            );
            reply($response);
        }

        if(ENVIRONMENT == 'testing' || ENVIRONMENT == 'production'){
            //set school_id variable
            $this->school_id = $this->Modelsession->get_school_id($this->input->get_request_header('Authorization', TRUE));

            //if null, reply with 403 status
            if($this->school_id == null){
                $response = array(
                    'status' => 403,
                    'message' => 'MISSING SCHOOL ID',
                    'data' => null
                );
                reply($response);
            }
        }
    }

    public function all(){
        $response = array(
            'status' => 200,
            'message' => 'Fetch all book',
            'data' => $this->Modelbook->get_all($this->school_id)
        );

        reply($response);
    }

    public function min(){
        $response = array(
            'status' => 200,
            'message' => 'Fetch minimal info of all book',
            'data' => $this->Modelbook->get_all_min($this->school_id)
        );

        reply($response);
    }

    public function create(){
        $data = array(
            'isbn' => $this->input->post('isbn'),
            'title' => $this->input->post('title'),
            'category' => $this->input->post('category')
        );

        if(!array_empty_check($data)){
            $response = array(
                'status' => 400,
                'message' => 'Invalid data',
                'data' => $data
            );
            reply($response);
        }

        //set school_id
        $data['school_id'] = $this->school_id;

        $status = $this->Modelbook->insert($data);

        if($status){
            $response = array(
                'status' => 201,
                'message' => 'Book created',
                'data' => $status
            );
        } else {
            $response = array(
                'status' => 500,
                'message' => 'Failed to create book',
                'data' => null
            );
        }

        reply($response);
    }

    public function update(){
        $id = $this->input->post('id');

        $data = array(
            'isbn' => $this->input->post('isbn'),
            'title' => $this->input->post('title'),
            'category' => $this->input->post('category')
        );

        $data = array_empty_remove($data);

        if(!array_empty_check($data)){
            $response = array(
                'status' => 400,
                'message' => 'Invalid data',
                'data' => $data
            );
            reply($response);
        }

        if(!$this->Modelbook->check_ownership($id, $this->school_id)){
            $response = array(
                'status' => 403,
                'message' => 'Book is not owned by this school',
                'data' => null
            );
            reply($response);
        }

        if($this->Modelbook->update($id, $data)){
            $response = array(
                'status' => 200,
                'message' => 'Book updated',
                'data' => null
            );
        } else {
            $response = array(
                'status' => 500,
                'message' => 'Failed to update book',
                'data' => null
            );
        }

        reply($response);
    }

    public function delete(){
        $id = $this->input->post('id');

        if(empty($id)) {
            $response = array(
                'status' => 400,
                'message' => 'Invalid data',
                'data' => null
            );
            reply($response);
        }

        if(!$this->Modelbook->check_ownership($id, $this->school_id)){
            $response = array(
                'status' => 403,
                'message' => 'Book is not owned by this school or it does not exist',
                'data' => null
            );
            reply($response);
        }

        //check if location is used in transaction
        /*
        if($this->Modeltrans->check_exist('agent_id', $id)){
            $response = array(
                'status' => 400,
                'message' => 'Agent is used in transaction',
                'data' => null
            );
            reply($response);
        }
        */

        if($this->Modelbook->delete($id)){
            $response = array(
                'status' => 200,
                'message' => 'Book deleted',
                'data' => null
            );
        } else {
            $response = array(
                'status' => 500,
                'message' => 'Failed to delete book',
                'data' => null
            );
        }

        reply($response);
    }
}
